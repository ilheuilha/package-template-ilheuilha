# package_name

Description. 
The package package_financas is used to:
	- Pandas
	- matplotlib

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_financas

```bash
pip install financas
```

## Author
Ilheuilha
